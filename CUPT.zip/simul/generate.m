function [fi]=generate(t,k)
z=linspace(0,2,10000);
fi=2*1*(-1)^k/pi/(2*k+1)*cos((2*k+1)*pi*z/2)...
    *exp(-(2*k+1)^2*pi*t);
end 
