function [x,y]=initial(y0,n)
M=ceil(y0/2*10000);
C=n(M);
y=linspace(0,y0,M);
x=zeros(1,M);
x(M)=1;
for k=M:-1:2
    if k==M
        delta=C/sqrt(n(k-2)^2-C^2);
    else
        delta=C/sqrt(n(k)^2-C^2)*1;
    end
    x(k-1)=x(k)-delta;
end
%plot(x,y);
end