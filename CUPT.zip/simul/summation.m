x=linspace(0,2,10000);
f=0;

for k=0:4000
    fk=generate(1,k);
    f=f+fk;
end
f=f+0.5;
n=(f-1)*(1.42-1.33)+1.42;
%plot(x,f,'linewidth',2);
%xlabel('Relative height $\frac{Z}{h}$','interpreter','latex')
%ylabel('Refrative Index n','interpreter','latex')
%title('Refrative Index-Relative height','interpreter','latex')

    