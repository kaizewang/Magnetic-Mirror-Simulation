x0=[0];
options=odeset('reltol',1e-10);
[y,x]=ode45(@odefun,[0,0.1],x0,options);