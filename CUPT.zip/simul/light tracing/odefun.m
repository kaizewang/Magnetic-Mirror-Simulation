function dxdy=odefun(y,x)
C=1.375007110311491;
dxdy=[C/sqrt((0.001392*y^3-0.004176*y^2+0.0003304*y+1.377)^2+10^(-8)-C^2)];
end